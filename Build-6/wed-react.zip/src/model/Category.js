export default class Category {
    constructor(id, categoryName, description) {
        this.id = id;
        this.categoryName = categoryName;
        this.description = description;
    }
}