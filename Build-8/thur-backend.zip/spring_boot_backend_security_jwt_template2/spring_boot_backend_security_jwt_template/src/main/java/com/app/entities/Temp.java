package com.app.entities;

public class Temp {

//	  "id": "pay_L0nSsccovt6zyp",
//	  "amount": 9900,
//	  "status": "captured",
//	  "order_id": "order_L0nS83FfCHaWqV",
//	  "invoice_id": "inv_L0nS7JIyuX6Lyb",
//	  "method": "card",
}
