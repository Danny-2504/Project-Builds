package com.app.service;

import com.app.dto.WishlistDto;
import com.app.entities.Wishlist;

public interface WishlistService {
	
	public WishlistDto addToWishList(WishlistDto wishlistDto); 

}
