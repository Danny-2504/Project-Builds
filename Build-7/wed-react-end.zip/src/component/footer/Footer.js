const Footer = () => {
    return (
        <div className="container-fluid bg-primary p-1 text-white">
            <p className="fs-6 text-center">ebook.com</p>
        </div>
    );
}

export {Footer};