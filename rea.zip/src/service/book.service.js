import axios from "axios";
import { BASE_API_URL } from "../common/constant";
import { AuthHeader } from "./auth.header";

const API_URL = BASE_API_URL + "/api/book";

class BookService {
    saveBook(book,file) {
        return axios.post(API_URL + "/add", book,file);
    }
    getAllBook() {
        return axios.get(API_URL + "/allbooks", { headers: AuthHeader() });
    }

    getAllBookByPag(pg) {
        return axios.get(API_URL + "/pages?pageNo="+pg);
    }

    getBookById(id) {
        return axios.get(API_URL + "/" + id);
    }

    // updateBook(b,imgFile) {
    //     return axios.post(API_URL + "/update?id="+b.id+"&bookName="+b.bookName+"&description="+b.description+"&author="+b.author+"&category="+b.category, imgFile ,{ headers : { 
    //         'Content-Type' : 'application/json'
    //     }}  );
    // }

    updateBook(b,imgFile) {
        return axios.post(API_URL +"/update/"+b.id);
    }

    deleteBook(id) {
        return axios.get(API_URL + "/delete/" + id);
    }

    countDetails() {
        return axios.get(API_URL + "/count");
    }

    getAllUser() {
        return axios.get(API_URL+"/getUser");
    }

    updateProfile(user) {
        return axios.post(API_URL + "/updateProfile", user, { headers: AuthHeader() });
    }

    searchBook(ch) {
        return axios.get(API_URL + "/search?ch=" + ch);
    }

    getAllCategories(){
        return axios.get(API_URL + "/categories");
    }


}

export default new BookService();